package com.example.springntr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringNtrApplicationTests {

    @Test
    void contextLoads() {
    }

}
