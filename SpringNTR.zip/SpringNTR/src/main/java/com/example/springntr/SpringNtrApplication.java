package com.example.springntr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringNtrApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringNtrApplication.class, args);
    }

}
